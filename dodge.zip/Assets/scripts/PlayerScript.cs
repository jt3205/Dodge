﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{

    public float speed;
    private float xInput;
    private float yInput;
    private Rigidbody2D myRigid;

	// Use this for initialization
	void Start ()
    {
        myRigid = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        xInput = Input.GetAxisRaw("Horizontal");
        yInput = Input.GetAxisRaw("Vertical");
	}

    private void FixedUpdate()
    {
        myRigid.velocity = new Vector2(xInput, yInput).normalized * speed;
    }
}
